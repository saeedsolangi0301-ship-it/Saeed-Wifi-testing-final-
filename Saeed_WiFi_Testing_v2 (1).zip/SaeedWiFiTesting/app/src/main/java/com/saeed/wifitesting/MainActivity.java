package com.saeed.wifitesting;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.DhcpInfo;
import android.net.Uri;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.net.HttpURLConnection;
import java.net.URL;

public class MainActivity extends Activity {
    private static final int REQ_LOCATION = 1001;

    private LinearLayout root;
    private TextView status;
    private WifiManager wifi;

    private int dp(float v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        wifi = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);

        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(22), dp(18), dp(22));
        root.setBackgroundColor(0xFFF4F7FB);

        ScrollView scroll = new ScrollView(this);
        scroll.addView(root);
        setContentView(scroll);

        TextView title = new TextView(this);
        title.setText("Saeed WiFi Testing");
        title.setTextSize(25);
        title.setTextColor(0xFF0D47A1);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, 0, 0, dp(6));
        root.addView(title);

        TextView sub = new TextView(this);
        sub.setText("Wi-Fi information & safe home-network checks");
        sub.setTextSize(14);
        sub.setGravity(Gravity.CENTER);
        sub.setTextColor(0xFF455A64);
        root.addView(sub);

        status = new TextView(this);
        status.setTextSize(15);
        status.setTextColor(0xFF263238);
        status.setPadding(dp(14), dp(14), dp(14), dp(14));
        status.setBackgroundColor(0xFFFFFFFF);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
        sp.topMargin = dp(18);
        root.addView(status, sp);

        addButton("Refresh Wi-Fi Details", v -> showWifi());
        addButton("Grant Location Permission (for SSID)", v -> requestLocationPermission());
        addButton("Open Wi-Fi Settings", v -> startActivity(new Intent(Settings.ACTION_WIFI_SETTINGS)));
        addButton("Open Router Admin Page", v -> openRouter());
        addButton("Check Password Strength", v -> passwordCheck());
        addButton("Internet Connection Test", v -> internetCheck());

        TextView note = new TextView(this);
        note.setText("\nSafety note: Use router settings and network checks only on networks you own or have permission to manage. This app does not crack passwords, generate WPS PINs, or attempt unauthorized access.");
        note.setTextSize(12);
        note.setTextColor(0xFF546E7A);
        root.addView(note);

        if (!hasLocationPermission()) {
            requestLocationPermission();
        }
        showWifi();
    }

    private void addButton(String text, View.OnClickListener listener) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
        p.topMargin = dp(10);
        root.addView(b, p);
        b.setOnClickListener(listener);
    }

    private boolean hasLocationPermission() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) {
            return true;
        }
        return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    private void requestLocationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (!hasLocationPermission()) {
                requestPermissions(new String[]{
                        Manifest.permission.ACCESS_FINE_LOCATION,
                        Manifest.permission.ACCESS_COARSE_LOCATION
                }, REQ_LOCATION);
            } else {
                Toast.makeText(this, "Location permission is already granted.", Toast.LENGTH_SHORT).show();
                showWifi();
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_LOCATION) {
            showWifi();
        }
    }

    @SuppressWarnings("deprecation")
    private void showWifi() {
        StringBuilder s = new StringBuilder();
        try {
            if (wifi == null) {
                s.append("Wi-Fi service is unavailable on this device.");
            } else if (!wifi.isWifiEnabled()) {
                s.append("Wi-Fi is OFF. Turn it on in Wi-Fi Settings.");
            } else {
                WifiInfo i = wifi.getConnectionInfo();
                String ssid = (i != null) ? i.getSSID() : null;
                if (ssid == null || ssid.equals("<unknown ssid>")) {
                    ssid = "Unavailable (grant Location permission & turn ON GPS/Location)";
                } else if (ssid.startsWith("\"") && ssid.endsWith("\"") && ssid.length() >= 2) {
                    ssid = ssid.substring(1, ssid.length() - 1);
                }
                int rssi = (i != null) ? i.getRssi() : 0;
                int speed = (i != null) ? i.getLinkSpeed() : 0;
                int freq = (i != null) ? i.getFrequency() : 0;
                int ipAddr = (i != null) ? i.getIpAddress() : 0;

                s.append("Connected Wi-Fi: ").append(ssid)
                 .append("\nSignal: ").append(rssi).append(" dBm (").append(signalLabel(rssi)).append(")")
                 .append("\nLink speed: ").append(speed).append(" Mbps")
                 .append("\nFrequency: ").append(freq).append(" MHz")
                 .append("\nIP address: ").append(ip(ipAddr))
                 .append("\nGateway: ").append(gateway());
            }
        } catch (Exception e) {
            s.append("Could not read Wi-Fi details: ").append(e.getMessage());
        }
        status.setText(s.toString());
    }

    private String signalLabel(int rssi) {
        if (rssi >= -55) return "Excellent";
        if (rssi >= -67) return "Good";
        if (rssi >= -75) return "Fair";
        return "Weak";
    }

    private String ip(int n) {
        return (n & 255) + "." + ((n >> 8) & 255) + "." + ((n >> 16) & 255) + "." + ((n >> 24) & 255);
    }

    @SuppressWarnings("deprecation")
    private String gateway() {
        try {
            DhcpInfo dhcp = wifi.getDhcpInfo();
            if (dhcp == null) return "Unavailable";
            return ip(dhcp.gateway);
        } catch (Exception e) {
            return "Unavailable";
        }
    }

    private void openRouter() {
        String g = gateway();
        if (g.equals("Unavailable") || g.equals("0.0.0.0")) {
            Toast.makeText(this, "Connect to your home Wi-Fi first", Toast.LENGTH_LONG).show();
            return;
        }
        try {
            Intent in = new Intent(Intent.ACTION_VIEW, Uri.parse("http://" + g));
            startActivity(Intent.createChooser(in, "Open router page"));
        } catch (Exception e) {
            Toast.makeText(this, "No browser found to open http://" + g, Toast.LENGTH_LONG).show();
        }
    }

    private void passwordCheck() {
        EditText e = new EditText(this);
        e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        e.setHint("Enter a sample password (not your real one)");
        new AlertDialog.Builder(this)
                .setTitle("Password Strength")
                .setView(e)
                .setPositiveButton("Check", (d, w) -> {
                    String p = e.getText().toString();
                    int score = 0;
                    if (p.length() >= 12) score++;
                    if (p.matches(".*[a-z].*")) score++;
                    if (p.matches(".*[A-Z].*")) score++;
                    if (p.matches(".*[0-9].*")) score++;
                    if (p.matches(".*[^A-Za-z0-9].*")) score++;
                    String r = score <= 2 ? "Weak — use a longer unique passphrase." :
                               score <= 3 ? "Fair — add length and variety." :
                               "Stronger — keep it unique.";
                    new AlertDialog.Builder(this)
                            .setTitle("Result")
                            .setMessage(r + "\nNever reuse passwords.")
                            .setPositiveButton("OK", null)
                            .show();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void internetCheck() {
        status.setText("Checking internet connection...");
        new Thread(() -> {
            long start = System.currentTimeMillis();
            boolean ok = false;
            int code = -1;
            HttpURLConnection conn = null;
            try {
                URL url = new URL("https://connectivitycheck.gstatic.com/generate_204");
                conn = (HttpURLConnection) url.openConnection();
                conn.setConnectTimeout(4000);
                conn.setReadTimeout(4000);
                conn.setRequestMethod("GET");
                code = conn.getResponseCode();
                ok = (code == 204 || code == 200);
            } catch (Exception ignored) {
            } finally {
                if (conn != null) conn.disconnect();
            }
            long elapsed = System.currentTimeMillis() - start;
            final boolean result = ok;
            final int httpCode = code;
            runOnUiThread(() -> {
                if (result) {
                    status.setText("Internet Connected!\nResponse: HTTP " + httpCode + "\nLatency: " + elapsed + " ms");
                } else {
                    status.setText("No internet response received.\nCheck your Wi-Fi or router connection.");
                }
            });
        }).start();
    }
}
