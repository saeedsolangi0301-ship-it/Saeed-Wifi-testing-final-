# Saeed WiFi Testing (Android Source Project - v2)

Clean Android source project ready for GitHub Actions APK build (Android 6.0+ / tested for Android 13+).

## Features
- Displays connected Wi-Fi SSID (with runtime Location permission request), signal strength (RSSI), link speed, frequency, IP address, and router gateway
- Direct shortcut to Android Wi-Fi settings
- Opens local router admin gateway page safely
- Local password-strength checker (use sample passwords only)
- Reliable HTTP internet connectivity & latency check

## Build via GitHub Actions
1. Upload `Saeed_WiFi_Testing_v2.zip` to the root of your GitHub repository.
2. Add `.github/workflows/android.yml` to the repository.
3. Open the **Actions** tab and download the generated `Saeed-WiFi-Testing-APK` artifact after the build succeeds.
